package btime

import "gobalance/pkg/clockwork"

var Clock = clockwork.NewRealClock()
